create trigger TR_PK_ACCOUNT
    before insert
    on ACCOUNT
    for each row
begin
        select sq_pk_account.nextval into :NEW.account_number from DUAL;
    end;
/

