create trigger TR_INSERT_BANK_USER
    before insert
    on BANK_USER
    for each row
begin
        SELECT sq_pk_Bank_user.NEXTVAL INTO :NEW.userid FROM DUAL;
    end;
/

