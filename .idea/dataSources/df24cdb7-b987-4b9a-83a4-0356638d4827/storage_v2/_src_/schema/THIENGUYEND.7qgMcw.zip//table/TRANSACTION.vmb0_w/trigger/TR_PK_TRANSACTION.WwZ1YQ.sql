create trigger TR_PK_TRANSACTION
    before insert
    on TRANSACTION
    for each row
begin
        select sq_pk_transaction.nextval into :NEW.transactionID from DUAL;
    end;
/

